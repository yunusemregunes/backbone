# Employee Management System Client

### Prerequirements:
* Node JS v8.9.0

### Steps to run the project:
* Run this command from terminal ´npm install´
* Run this command from terminal ´npm run start´
* Open ´localhost:8081´ from explorer
