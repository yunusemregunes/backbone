require(['config'], function () {
    require([
        'app'
    ], function(App) {
        App.initialize();
    });
});
