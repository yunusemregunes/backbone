require.config({
        baseUrl: 'scripts',
        paths: {
                'jquery': 'vendors/jquery/jquery-1.11.2',
                'underscore': 'vendors/underscore/underscore',
                'text': 'vendors/require/text',
                'backbone': 'vendors/backbone/backbone'
        }
});
