define([
    'backbone'
], function (
    Backbone
) {
    var EmployeeAddress = Backbone.Model.extend({
       urlRoot:'/api/addresses',

    });
    return EmployeeAddress;
});
