define([
    'backbone'
], function (
    Backbone
) {
    var Department = Backbone.Model.extend({
       urlRoot:'/api/departmants',

    });
    return Department;
});
