define([
    'backbone'
], function (
    Backbone
) {
    var Employee = Backbone.Model.extend({
        urlRoot:'/api/employees',

        validate: function (attrs) {
            if (attrs.name == "" || attrs.surname == "" || attrs.email == "" || attrs.age == NaN || attrs.department == "") {
                return "Please fill all the blanks..";
            }
        }
    });
    return Employee;
});
