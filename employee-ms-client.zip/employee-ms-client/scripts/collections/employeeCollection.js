define([
    'backbone',
    'models/employeeModel'
], function (
    Backbone,
    Employee
) {
    var EmployeeList = Backbone.Collection.extend({
        model: Employee,
        url: '/api/employees'

    });
    return EmployeeList;
});
