define([
    'backbone',
    'models/employeeAddress'
], function (
    Backbone,
    EmployeeAddress
) {
    var EmployeeAddressList = Backbone.Collection.extend({
        model: EmployeeAddress,
        url: '/api/addresses'

    });
    return EmployeeAddressList;
});
