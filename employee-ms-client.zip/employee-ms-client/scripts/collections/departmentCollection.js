define([
    'backbone',
    'models/department'
], function (
    Backbone,
    Department
) {
    var DepartmentList = Backbone.Collection.extend({
        model: Department,
       url: '/api/departmants'

    });
    return DepartmentList;
});
