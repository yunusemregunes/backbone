define([
    'jquery',
    'underscore',
    'backbone',
    'views/employee/menu',
    'views/employee/listView',
    'views/chooseManagerListView',
    'collections/employeeCollection',
    'models/employeeModel',

],
    function ($, _, Backbone, MenuView, ListView, ChooseManagerListView, EmployeeCollection, EmployeeModel) {

        var AppRouter = Backbone.Router.extend({
            vent: _.extend({}, Backbone.Events),
            routes: {
                '': 'home',
                'home': 'home',
                '*actions': 'home'
            }
        });

        var initialize = function () {
            var appRouter = new AppRouter();
            var vent = appRouter.vent;

            appRouter.on('route:home', function () {

                new EmployeeCollection().fetch({
                    success: function (model, res) {
                        new MenuView({ model,"vent": vent });
                        var view = new ListView({ model, "vent": vent });
                        view.render();
                        
                    },
                    error: function (res) {
                        console.error("collection fetch error", res);
                    }
                });
            });
            Backbone.history.start();
        };

        return {
            initialize: initialize
        };
    });
