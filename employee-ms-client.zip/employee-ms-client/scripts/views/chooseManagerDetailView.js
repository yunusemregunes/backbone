define([
    'jquery',
    'underscore',
    'backbone',
    'collections/employeeCollection',
    'models/employeeModel',
    'text!../templates/employee/chooseManager.html',
],
    function ($, _, Backbone, EmployeeList, Employee, ChooseManagerTemplate) {

        var ChooseManagerDetailView = Backbone.View.extend({
            tagName: "div",

            events: {
                "click .managerName": "managerNameBtnClicked",
            },

            initialize: function (options) {
                this.vent = options.vent;
                this.model=options.model;
               // console.log("this.model",this.model);

            },

            render: function () {
                var chooseManagerDetailTemplate = _.template(ChooseManagerTemplate, {});
                this.$el.html(chooseManagerDetailTemplate(this.model.toJSON()));
                return this;
            },

            managerNameBtnClicked: function () {
                $("#chooseManager").html("");
                $("#chooseManager").html(this.model.get("firstName")+" "+this.model.get("lastName"));
            },
            
        });
        return ChooseManagerDetailView;
    });
