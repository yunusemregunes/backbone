define([
    'jquery',
    'underscore',
    'backbone',
    'text!../../templates/employee/menu.html',
    'collections/employeeCollection',
    'routes/router',
    'views/chooseManagerListView',
    'views/chooseDepartmentListView',
    'views/employee/listView'

],
    function ($, _, Backbone, MenuTemplate, Employee, router, ChooseManagerListView, ChooseDepartmentListView, ListView) {

        var MenuView = Backbone.View.extend({

            el: '.menu',
            events: {
                "click #add-employee": "addEmployee",
                "click #addEmployeeModalBtn":"addEmployeeModalBtnClicked",
                "click #findButton": "filter",
                "click .fa-trash-alt": "clear",
                "click .createDepartment": "showCreateDepartment",
                "click .fa-arrow-circle-left": "hideCreateDepartmentViewBtnClicked",
                "click #chooseManager": "chooseManagerViewBtnClicked",
                "click #chooseDepartment": "chooseDepartmentViewBtnClicked"

            },

            initialize: function (options) {
                this.vent = options.vent;
                this.model = options.model;
                console.log("cxczxczcx", this.vent, "aa", this.model);
                this.render();
            },

            render: function () {
                var compiledTemplate = _.template(MenuTemplate, {});
                this.$el.html(compiledTemplate);

            },

            addEmployee: function () {
                console.log("add employee", this.vent);
                this.vent.trigger("addEmployee");
            },

            addEmployeeModalBtnClicked:function(){
                this.render();
            },

            filter: function () {
                var searchFilter = $("#search").val();
                this.vent.trigger("inputFilter", searchFilter);
            },

            clear: function () {
                this.vent.trigger("inputClear");
            },

            showCreateDepartmentViewBtnClicked: function () {
                $(".createNewDepartment").hide();
                $(".addEmployeeModalCreateDepartment").show();
                $(".fa-arrow-circle-left").show();
            },

            hideCreateDepartmentViewBtnClicked: function () {
                $(".createNewDepartment").show();
                $(".addEmployeeModalCreateDepartment").hide();
                $(".fa-arrow-circle-left").hide();
            },

            chooseManagerViewBtnClicked: function () {
                var self = this;
                var view = new ChooseManagerListView({ model: this.model, "vent": this.vent, el: (".chooseManager") });
                view.render();
            },

            chooseDepartmentViewBtnClicked:function(){
                var self = this;
                console.log("menu view",this.model);
                var view = new ChooseDepartmentListView({ model: this.model, "vent": this.vent, el: (".chooseDepartment") });
                view.render();
            }


        });
        return MenuView;
    });
