define([
    'jquery',
    'underscore',
    'backbone',
    'text!../../templates/employee/employee.html',
    'collections/employeeCollection',
    'collections/departmentCollection',
    'models/employeeModel',
    'models/department'


],
    function ($, _, Backbone, EmployeeTemplate, EmployeeList, DepartmentList, Employee, Department) {

        var DetailView = Backbone.View.extend({
            tagName: "div",
            events: {
                "click .delete": "delete",
                "click .editbtn": "edit",
                "click .info-btn": "showInfo",
                "click .showDetailDepartmentInfoModal": "showDetailDepartmentInfoModalBtnClicked",
                "click .showDetailAddressInfoModal": "showDetailAddressInfoModalBtnClicked"
            },

            initialize: function (options) {
                this.vent = options.vent;
            },

            render: function () {
                var detailTemplate = _.template(EmployeeTemplate, {});
                var name = this.model.get("firstName");
                var surname = this.model.get("lastName");
                var firstCharName = name.charAt(0);
                var firstCharSurname = surname.charAt(0);
                this.model.set('profileImgTxt', firstCharName + firstCharSurname)
                this.$el.html(detailTemplate(this.model.toJSON()));
                return this;
            },

            delete: function (e, options) {
                this.vent.trigger("deleteEmployee", this.model);
            },

            edit: function (e, options) {
                this.vent.trigger("editEmployee", this.model);
            },

            showInfo: function () {
                this.render();
                console.log("aaa"+this.model.attributes.departmant.id);
                $(".employeeName").html(this.model.get("firstName") + this.model.get("lastName"));
                $(".employeeEmail").html(this.model.get("email"));
                $(".employeeAge").html(this.model.get("age"));
                $(".employeeDepartmant").html(this.model.attributes.departmant.name);
                if (this.model.attributes.manager === null) {
                    $(".employeeManager").html("");
                }
                else {
                    $(".employeeManager").html(this.model.attributes.manager.firstName + " " + this.model.attributes.manager.lastName);
                }
                $(".employeeAddress").html(this.model.attributes.employeeAdresses[0].country + ", " + this.model.attributes.employeeAdresses[0].state);


                var date = this.model.attributes.dateJoined;
                var dateJoined = date.substring(0, 10);
                $(".employeeDateJoined").html(dateJoined);


            },

            showDetailDepartmentInfoModalBtnClicked: function () {
                
                console.log(this.model);
                $(".departmentName").html(this.model.attributes.departmant.name);
                $(".departmentPhone").html(this.model.attributes.departmant.phone);
                $(".departmentLocation").html(this.model.attributes.departmant.location);
            },

            showDetailAddressInfoModalBtnClicked: function () {
                console.log("clicked");
                console.log(this.model.get("id"));
                $(".addressCountry").html(this.model.attributes.employeeAdresses[0].country);
                console.log(this.model.attributes.employeeAdresses[0].state);
                $(".addressState").html(this.model.attributes.employeeAdresses[0].state);
                $(".addressPostalCode").html(this.model.attributes.employeeAdresses[0].postalCode);
                $(".addressHomeNo").html(this.model.attributes.employeeAdresses[0].homeNumber);
            }

        });
        return DetailView;
    });
