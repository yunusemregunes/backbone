define([
    'jquery',
    'underscore',
    'backbone',
    'text!../../templates/employee/employee.html',
    'models/employeeModel',
    'collections/employeeCollection',
    'views/employee/detailView',
    'views/chooseManagerListView',
    'views/chooseDepartmentListView',
    'views/employee/menu'

],
    function ($, _, Backbone, EmployeeTemplate, Employee, EmployeeCollection, DetailView, ChooseManagerListView, ChooseDepartmentListView, Menu) {

        var ListView = Backbone.View.extend({
            el: $('.list'),
            events: {
                "click #update-employee": "updateEmployeeBtnClicked",
                "click #updateDepartment": "updateDepartmentViewBtnClicked",
                "click #updateManager": "updateManagerViewBtnClicked",
                
            },

            initialize: function (options) {
                var self = this;
                this.model = options.model;
                this.vent = options.vent;
                this.listenTo(this.vent, "deleteEmployee", this.deleteEmployee);
                this.listenTo(this.vent, "addEmployee", this.addEmployee);
                this.listenTo(this.vent, "inputFilter", this.inputFilter);
                this.listenTo(this.vent, "editEmployee", this.fillEditModal);
                this.listenTo(this.vent, "inputClear", this.inputClear);
            },

            render: function () {
                var self = this;
                this.$el.html("");
                $(".list").empty();
                var searchFilter = this.searchFilter;
                _.each(this.model.toArray(), function (employee) {
                    if ((searchFilter == undefined || employee.get("firstName").toLocaleLowerCase('tr-TR').includes(searchFilter.toLocaleLowerCase('tr-TR')))) {
                        self.$el.append((new DetailView({ model: employee, "vent": self.vent })).render().$el);
                    }
                });
            },

            deleteEmployee: function (model) {
                model.destroy();
                var self = this;
                var oldModel = this.model;

                _.each(oldModel.toArray(), function (employee) {
                    if (employee.get("id") == model.get("id")) {
                        self.model.remove(employee);
                    }
                });
                this.render();
            },

            addEmployee: function () {
                var self = this;
                var employee = new Employee();
                employee.set({ "firstName": $("#name").val() });
                employee.set({ "lastName": $("#surname").val() });
                employee.set({ "age": parseInt($("#age").val()) });
                employee.set({ "email": $("#email").val() });
                employee.set({ "departmant": $("#department").val() });

                if (employee.isValid()) {
                    employee.save().then((res) => {
                        if (res.hasOwnProperty("id")) {
                            self.model.push(res);
                            self.render();
                        }
                    });
                }
                else {
                    alert(employee.validationError);
                }
            },

            fillEditModal: function (employee) {
                var self = this;
                $("#editName").val(employee.get("firstName"));
                $("#editSurname").val(employee.get("lastName"));
                $("#editAge").val(employee.get("age"));
                $("#editEmail").val(employee.get("email"));
                $("#updateDepartment").html("");
                $("#updateDepartment").html(employee.get("department"));
                $("#updateManager").html("");
                $("#updateManager").html(employee.get("firstName")+" "+employee.get("lastName"));

            },

            updatedEmployeeBtnClicked: function () {
                var self = this;
                var oldModel = this.model;
                _.each(oldModel.toArray(), function (employee) {

                    if (employee.get("id") == $("#edit-employee").attr("firstName")) {
                        employee.set({ "name": $("#editName").val() });
                        employee.set({ "surname": $("#editSurname").val() });
                        employee.set({ "age": $("#editAge").val() });
                        employee.set({ "email": $("#editEmail").val() });
                        employee.set({ "department": $("#editDepartment").val() });
                        employee.save().then((res) => {
                            if (res.hasOwnProperty("id")) {
                                self.model.push(res);
                                setTimeout(function () {
                                    self.render();
                                }, 500);
                            }
                        });
                    }
                });
            },

            updateDepartmentViewBtnClicked: function () {
                var view = new ChooseDepartmentListView({ model: this.model, "vent": this.vent, el: (".editEmployeeDepartment") });
                view.render();
            },

            updateManagerViewBtnClicked: function () {
                var view = new ChooseManagerListView({ model: this.model, "vent": this.vent, el: (".editEmployeeManager") });
                view.render();
            },

            inputFilter: function (searchFilter) {
                var self = this;
                this.searchFilter = searchFilter;
                this.render();
            },

            inputClear: function () {
                $("#search").val("");
                this.inputFilter("");
            }
        });
        return ListView;
    });
