define([
    'jquery',
    'underscore',
    'backbone',
    'collections/employeeCollection',
    'models/employeeModel',
    'text!../templates/employee/chooseDepartment.html',
],
    function ($, _, Backbone,  EmployeeList, Employee, ChooseDepartmentTemplate) {

        var ChooseDepartmentDetailView = Backbone.View.extend({
            tagName: "div",

            events:{
                "click .departmentName": "departmentNameBtnClicked"
            },
    
            initialize: function (options) {
                this.vent = options.vent;
                
            },

            render: function () {
                console.log("this.model",this.model.get("firstName"));
                var chooseDepartmentDetailTemplate = _.template(ChooseDepartmentTemplate, {});
                this.$el.html(chooseDepartmentDetailTemplate(this.model.toJSON()));
                return this;
            },

            departmentNameBtnClicked: function(){
                console.log("deaprtmenttttt",this.model);
                $("#chooseDepartment").html("");
                console.log(this.model.get("departmant"));
                $("#chooseDepartment").html(this.model.get("departmant"));
            }

        });
        return ChooseDepartmentDetailView;
    });
