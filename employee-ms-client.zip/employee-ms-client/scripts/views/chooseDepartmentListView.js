define([
    'jquery',
    'underscore',
    'backbone',
    'text!../templates/employee/chooseDepartment.html',
    'models/employeeModel',
    'collections/employeeCollection',
    '../views/chooseDepartmentDetailView',

],
    function ($, _, Backbone, ChooseDepartmentTemplate, Employee, EmployeeCollection, ChooseDepartmentDetailView) {

        var ChooseDepartmentListView = Backbone.View.extend({
            
            initialize: function (options) {

                var self = this;
                this.model = options.model;
                this.vent = options.vent;
            },

            render: function () {
                var self = this;
                this.$el.html("");

                _.each(this.model.toArray(), function (employee) {
                    self.$el.append((new ChooseDepartmentDetailView({ model: employee, "vent": self.vent })).render().$el);

                });
                return this;
            },


        });
        return ChooseDepartmentListView;
    });
