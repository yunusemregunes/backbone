define([
    'jquery',
    'underscore',
    'backbone',
    'text!../templates/employee/chooseManager.html',
    'models/employeeModel',
    'collections/employeeCollection',
    'views/chooseManagerDetailView',

],
    function ($, _, Backbone, ChooseManagerTemplate, Employee, EmployeeCollection, ChooseManagerDetailView) {

        var ChooseManagerListView = Backbone.View.extend({
            initialize: function (options) {

                var self = this;
                this.model = options.model;
                this.vent = options.vent;
            },

            render: function () {
                var self = this;
                this.$el.html("");

                _.each(this.model.toArray(), function (employee) {
                    console.log("a");

                    self.$el.append((new ChooseManagerDetailView({ model: employee, "vent": self.vent })).render().$el);

                });
                return this;
            },


        });
        return ChooseManagerListView;
    });
