var gulp = require('gulp'),
    proxy = require('http-proxy-middleware'),
    connect = require('gulp-connect');

gulp.task('connect', function () {
    connect.server({
        host:'0.0.0.0',
        root: './',
        port: 8000,
        livereload: false,
        middleware: function (connect, o) {
            var apiProxy = proxy('/api', {
                target: 'http://localhost:8081',
                changeOrigin: true
            });
            return [apiProxy];
        }
    });
});

gulp.task('default', gulp.series('connect'));
